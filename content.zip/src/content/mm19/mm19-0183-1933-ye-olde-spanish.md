---
iaid: x998723668805867
minino: '0183'
minifn: mm19-0183-1933-ye-olde-spanish
minititle: 'Ye Olde Spanish Main, 1933'
minislug: '1933-ye-olde-spanish'
essayno: 'mm19'
essaytitle: 'Around, Over, and Through the Americas'
essaysubtitle: ''
essayslug: around-over-through
manifest: 2KXJ8ZSF20ISO
imagetitle: 'The Grace Line dedicates this carte to ye olde Spanish Main, cradle of our western civilization'
imagectxid: NL11JAE6
imageiiifid: 2KXJ8ZSF20VP7
imagelink: 2KXJ8ZSF20VP7
---
By the early twentieth century, tens of thousands of North Americans were joining their forebears in setting sail for the Spanish Main—the islands of the Caribbean and countries of Central America. Some followed in the footsteps of businessmen like Joseph Dimock, and came to invest in agriculture, whether sugar in Cuba or coffee in Central America and Colombia; others followed writers like Richard Henry Dana (on an 1859 “Vacation voyage”) or Julia Ward Howe, who the next year mocked the “undistinguishable individuals who we class together as Yankees…the Southerner being as like the Northerner as a dried pea is to a green pea” on a “trip to Cuba.” Increasing numbers were on a family vacation, with nothing more in mind than a holiday of one to three weeks with the chance to see new sites, taste tropical fruits, and escape winter. 

Still, as in the nineteenth century, fleets served multiple purposes. Grace Line was first and foremost a freight line, bringing nitrates, sugar, coffee, and other products from company properties in Peru, Bolivia, and trading partners in Central and South America. It also earned substantial revenue after taking over PacMail’s contract to deliver US mail from the East to West coasts via the Panama Canal. And it also carried passengers, at first largely businessmen but increasingly the leisure traveler. W.R. Grace was at intersection of commerce, communication, and tourism, a trifecta that shimmered in the romantic map-poster designed to entertain and entice passengers aboard. Who better to design such a map than an artist tied to both continents? 

Born in Uruguay to a Catalonian father and French mother, Joseph Jacinto (“Jo”) Mora (1876-1947) grew up in the US and lived most of his adult life in California and the Southwest, painting, drawing, sculpting, illustrating and writing, and the Spanish influence on the Americas and Western life were frequent themes. His “cartes” (charts) of California, Yosemite, and Carmel were illustrated maps and posters designed by and for himself. In 1933 Mora traveled on the invitation of Grace Lines and produced two works as a result. The first was a humorous but informative logbook, with vignettes and maps of ports of call and brief biographies and portraits of the principal pirates of the Caribbean. 

The second was a pictorial map of “Ye Olde Spanish Maine” integrating illustrative details of traditional cartography—ships and activities in the ocean, coasts from San Francisco to New York, via Panama—with contemporary and historical information. Drawing on cartographic traditions of a decorative nature, the map had a border of vignettes and several insets. The border (Left) shows scenes of history, from portraits of conquistadors and their principal successes, to a nod to Maya antiquities and Sir Francis Drake’s plundering, to Simon Bolívar’s independence movement. Along the right-hand side, the vignettes favor more tales of piracy and celebrate pears, Central American “king” coffee and Colombian emeralds. Across the top, a rough rider straddles the canal, while ‘types’ on horseback, muleback, and oxcart from Canada to Colombia approach the center waving national flags. Below the map, “ye past” of disorderly pirates, Spanish priests, and conquistadors contrasts with “ye present” of progress and the handshake of good neighbors. The Grace Line captain extends his hand to the demure Spanish señorita and her farmer beau, with a motley line of passengers sweating behind him. It is not just Uncle Sam and his military arm who link the hemisphere, as seen above, but the W.R. Grace Company, which (not coincidentally) has its own standard. 

Like the 1726 Carte Marine of Tierra Firme (FIGURE 1), and Codazzi’s 1840 Atlas (FIGURE 2), this “Spanish Maine” is in its “informative intent” “historical and topographical” yet, as Mora writes, “it is rendered in the manner humorous that its perusal may be accomplished rather with the smile of levity than the frown of research.” 

Despite the humor of the drawings, the map is generally accurate and the vignettes informative, both about the places visited and about Grace’s commercial interests. For example, the Guatemala inset, topped by the national bird, the quetzal, shows the route from cruise liner to shore at San José, and then the rail route to Guatemala, Mexico, or the USA, through banana and sugar lowlands, up into the foothills where coffee is grown, around the three volcanos on view from colonial center Antigua, and across Lake Amatitlán into Guatemala City, the destination and national capital. Transportation, agricultural export commodities, and tourist destinations were all elements of the Grace portfolio. The Panama Canal vignette offers the canal route side-by-side with the mid-nineteenth century railroad line, and offers statistical information of length, yearly capacity, US occupation, first use, and the fact that 7873 miles are shaved on trips to New York and San Francisco that can avoid the Magellan straits. The canal’s facilitation of trade between East and West Coast was central to Grace’s business model. 

