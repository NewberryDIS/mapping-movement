---
iaid: x995575758805867
minino: '0086'
minifn: mm09-0086-1775-carolinas
minititle: 'The Carolinas and their Indian Frontiers, 1775'
minislug: '1775-carolinas'
essayno: 'mm09'
essaytitle: 'Moving Pictures'
essaysubtitle: 'Maps and Imagination in Eighteenth-Century Anglo-America'
essayslug: moving-pictures
manifest: 2KXJ8ZSQ38TO6
imagetitle: 'An accurate map of North and South Carolina with their Indian frontiers shewing in a distinct manner all the mountains, rivers, swamps, marshes, bays,...'
imagectxid: NL11JNXQ
imageiiifid: 2KXJ8ZSFHN8QM
imagelink: 2KXJ8ZWQT8EP
---


